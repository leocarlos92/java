package com.example.actuatorservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ActuatorserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
