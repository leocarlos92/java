package com.example.actuatorservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ActuatorserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ActuatorserviceApplication.class, args);
	}

}
