package com.javatechie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VtTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
