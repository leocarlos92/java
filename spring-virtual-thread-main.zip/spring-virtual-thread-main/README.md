# spring-virtual-thread

## Jmeter Test results :

### Platform Thread
![Screenshot 2023-12-16 at 9 53 22 AM](https://github.com/Java-Techie-jt/spring-virtual-thread/assets/25712816/03978099-4df3-4686-a6e6-8eb1f28ab69f)

### Virtual Thread
![Screenshot 2023-12-16 at 9 59 04 AM](https://github.com/Java-Techie-jt/spring-virtual-thread/assets/25712816/2f82ae30-41f3-4f29-a1de-10e6661840cf)
